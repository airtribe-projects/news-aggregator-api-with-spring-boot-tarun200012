package com.example.newsapp.service;

import com.example.newsapp.entity.Preference;
import com.example.newsapp.entity.User;
import com.example.newsapp.repository.PreferenceRepository;
import com.example.newsapp.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PreferenceService {

    private final PreferenceRepository preferenceRepository;
    private final UserRepository userRepository;

    public PreferenceService(PreferenceRepository preferenceRepository, UserRepository userRepository) {
        this.preferenceRepository = preferenceRepository;
        this.userRepository = userRepository;
    }

    public Preference savePreference(Long userId, Preference preference) {
        Optional<User> optionalUser = userRepository.findById(userId);

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            preference.setUser(user);
            return preferenceRepository.save(preference);
        } else {
            throw new RuntimeException("User not found with id: " + userId);
        }
    }

    public List<Preference> getPreferencesByUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));
        return getPreferencesByUser(user);
    }

    public List<Preference> getPreferencesByUser(User user) {
        return preferenceRepository.findByUser(user);
    }

    public List<Preference> replacePreferences(User user, List<String> categories) {
        // Delete old preferences
        preferenceRepository.deleteAll(user.getPreferences());

        // Add new preferences
        for (String category : categories) {
            Preference preference = new Preference();
            preference.setCategory(category);
            preference.setUser(user);
            preferenceRepository.save(preference);
        }

        // Return updated preferences
        return preferenceRepository.findByUser(user);
    }
}
