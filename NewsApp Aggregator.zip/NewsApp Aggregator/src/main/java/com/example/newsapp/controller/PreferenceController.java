package com.example.newsapp.controller;

import com.example.newsapp.entity.Preference;
import com.example.newsapp.entity.User;
import com.example.newsapp.repository.PreferenceRepository;
import com.example.newsapp.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/preferences")
public class PreferenceController {

    private final PreferenceRepository preferenceRepository;
    private final UserRepository userRepository;

    public PreferenceController(PreferenceRepository preferenceRepository, UserRepository userRepository) {
        this.preferenceRepository = preferenceRepository;
        this.userRepository = userRepository;
    }

    @PostMapping("/add")
    public ResponseEntity<?> addPreferences(Authentication authentication, @RequestBody List<String> categories) {
        User user = userRepository.findByUsername(authentication.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        for (String cat : categories) {
            Preference p = new Preference();
            p.setCategory(cat);
            p.setUser(user);
            preferenceRepository.save(p);
        }

        return ResponseEntity.ok("Preferences added successfully");
    }
}
