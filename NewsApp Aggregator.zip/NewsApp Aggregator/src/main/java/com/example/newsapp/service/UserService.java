package com.example.newsapp.service;

import com.example.newsapp.entity.User;
import com.example.newsapp.entity.Preference;
import com.example.newsapp.repository.UserRepository;
import com.example.newsapp.repository.PreferenceRepository;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PreferenceRepository preferenceRepository;

    public UserService(UserRepository userRepository, PreferenceRepository preferenceRepository) {
        this.userRepository = userRepository;
        this.preferenceRepository = preferenceRepository;
    }

    public User saveUser(User user) {
        if(userRepository.existsByUsername(user.getUsername())) {
            throw new RuntimeException("Username already exists");
        }

        // Save user first
        User savedUser = userRepository.save(user);

        // Link preferences
        if (user.getPreferences() != null) {
            for (Preference p : user.getPreferences()) {
                p.setUser(savedUser);
            }
            preferenceRepository.saveAll(user.getPreferences());
        }

        return savedUser;
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }
}
