package com.example.newsapp.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
public class NewsService {

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final String API_KEY = "27a3aca350144fdaabf32d613b8cef21"; // Replace with your NewsAPI key

    public Map<String, Object> getNewsByCategory(String category) {
        String url = "https://newsapi.org/v2/top-headlines?category=" + category + "&country=us&apiKey=" + API_KEY;

        String response = restTemplate.getForObject(url, String.class);

        try {
            // Convert JSON string to Map
            return objectMapper.readValue(response, Map.class);
        } catch (Exception e) {
            e.printStackTrace();
            return Map.of("error", "Unable to fetch news");
        }
    }
}
