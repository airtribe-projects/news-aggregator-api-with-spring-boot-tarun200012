package com.example.newsapp.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.newsapp.entity.Preference;

public interface PreferencesRepository extends JpaRepository<Preference, Long> {
}
