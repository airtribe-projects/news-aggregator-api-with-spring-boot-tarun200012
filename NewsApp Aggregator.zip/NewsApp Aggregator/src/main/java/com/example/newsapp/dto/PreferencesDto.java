package com.example.newsapp.dto;

public class PreferencesDto {
    private String category;
    private String language;
    private String country;

    public PreferencesDto() {}

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }
}
