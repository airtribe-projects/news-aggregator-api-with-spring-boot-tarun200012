package com.example.newsapp.dto;

import java.util.List;

import com.example.newsapp.entity.Preference;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class RegisterRequest {
    private String username;
    private List<Preference> preferences; // optional

    @NotBlank
    @Size(min = 4, message = "Password must be at least 4 characters")
    private String password;

    public RegisterRequest() {}

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }


	public List<Preference> getPreferences() {
		return preferences;
	}

	public void setPreferences(List<Preference> preferences) {
		this.preferences = preferences;
	}
    
}
