package com.example.newsapp.controller;

import com.example.newsapp.entity.Preference;
import com.example.newsapp.entity.User;
import com.example.newsapp.service.NewsService;
import com.example.newsapp.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/news")
public class NewsController {

    private final NewsService newsService;
    private final UserService userService;

    public NewsController(NewsService newsService, UserService userService) {
        this.newsService = newsService;
        this.userService = userService;
    }

    @GetMapping
    public Map<String, Object> getNews(Authentication authentication) {
        User user = userService.findByUsername(authentication.getName());
        List<Preference> prefs = user.getPreferences();

        Map<String, Object> out = new HashMap<>();
        if (prefs == null || prefs.isEmpty()) {
            out.put("general", newsService.getNewsByCategory("general"));
        } else {
            for (Preference p : prefs) {
                out.put(p.getCategory(), newsService.getNewsByCategory(p.getCategory()));
            }
        }

        return out;
    }
}
