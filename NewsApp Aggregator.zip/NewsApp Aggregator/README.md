# NewsApp

Spring Boot JWT + H2 + Preferences + News API.

## Endpoints
- POST /api/register
- POST /api/login
- GET /api/preferences
- PUT /api/preferences
- GET /api/news

## Run
1. Set `news.api.key` in `src/main/resources/application.properties`.
2. `./mvnw spring-boot:run`

## Test (curl)
Register:
```sh
curl -X POST http://localhost:8080/api/register -H "Content-Type: application/json" -d '{"username":"alice","password":"pass"}'
```
Login (get token):
```sh
curl -X POST http://localhost:8080/api/login -H "Content-Type: application/json" -d '{"username":"alice","password":"pass"}'
```
Save preferences:
```sh
curl -X PUT http://localhost:8080/api/preferences -H "Authorization: Bearer <TOKEN>" -H "Content-Type: application/json" -d '{"categories":["technology","sports"]}'
```
Get news:
```sh
curl -X GET http://localhost:8080/api/news -H "Authorization: Bearer <TOKEN>"
```
